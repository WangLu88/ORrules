threshold_2d <-
  function (D,x,y,w,option=1)
  {
    #option=1: or rule;option=0: and rule
    n=length(D)
    cCode="threshold2d"
    maxtheta=0
    xthresholds=rep(0,(n+1)*(n+1))
    ythresholds=rep(0,(n+1)*(n+1))
    numthresholds=0
    rResult <- .C(cCode,D=as.integer(D),x=as.double(x),y=as.double(y),n=as.integer(n),w=as.double(w),
                  option=as.integer(option),maxtheta=as.double(maxtheta),xthresholds=as.double(xthresholds),
                  ythresholds=as.double(ythresholds),
                  numthresholds=as.integer(numthresholds),PACKAGE="gettheta")
    maxtheta=rResult$maxtheta
    thresholds=data.frame(matrix(NA,nrow=rResult$numthresholds,ncol=2))
    colnames(thresholds)=c("x","y")
    thresholds$x=rResult$xthresholds[1:rResult$numthresholds]
    thresholds$y=rResult$ythresholds[1:rResult$numthresholds]
    return(list(maxtheta=maxtheta,thresholds=thresholds))
  }
