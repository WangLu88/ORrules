threshold_1d <-
function (D,x,w)
{
  n=length(D)
  cCode="threshold1"
  maxtheta=0
  xthresholds=rep(0,n+1)
  numxthresholds=0
  rResult <- .C(cCode,D=as.integer(D),x=as.double(x),n=as.integer(n),w=as.double(w),maxtheta=as.double(maxtheta),
                xthresholds=as.double(xthresholds),numxthresholds=as.integer(numxthresholds),PACKAGE="gettheta")
  maxtheta=rResult$maxtheta
  thresholds=rResult$xthresholds[1:rResult$numxthresholds]
  return(list(maxtheta=maxtheta,thresholds=thresholds))
}
