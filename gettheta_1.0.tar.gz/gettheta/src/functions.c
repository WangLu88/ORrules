# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <float.h>
# include <string.h>
//# include <R.h>
//# include <Rmath.h>

/*
static void errmsg(char *string){

 //  Function to emulate "stop" of S+ - see page 134, S Programing, by
 //    Venables and Ripley 

   PROBLEM "%s", string RECOVER(NULL_ENTRY);
}
*/

//for debug
void print_matrix_double(double **m, int nrow, int ncol, FILE *file){
  int i,j;
  for (i=0;i<nrow;i++) {
    for (j=0;j<ncol;j++){
          if (j==0) fprintf(file,"\n%.4e",m[i][j]);
          else fprintf(file,"\t%.4e",m[i][j]);
    }
  }
}

void print_vector_double(double *m, int n, FILE *file){
    int j; 
    for (j=0;j<n;j++){
          if (j==0) fprintf(file,"%f\n",m[j]);
          else fprintf(file,"%f\n",m[j]);
    }
  
}

//for qsort
int compare (const void * a, const void * b)
{
	if ( *(double*)a < *(double*)b ) 
		return -1;
	else if (*(double*)a == *(double*)b ) 
		return 0;
	else
		return 1;
}

//double array structure
struct double_array {
	int size;
	double * pos;
};

//int array structure
struct int_array {
	int size;
	int * pos;
};

//sort and find unique element of double array
struct double_array sort_unique_array(double *x, int n)
{
	qsort(x,n,sizeof(double),compare);
	double *x1= (double *) calloc(n,sizeof(double));
	*x1=*x;	
	int i,j;
	j=0;
	for (i=1;i<n;i++)
	{
		if ( *(x+i) != *(x+i-1) )
		{
			j++;
			*(x1+j)=*(x+i);		
		}
	}	
	struct double_array res_array;
	res_array.size=j+1;
	res_array.pos=x1;
	return res_array;
}	

//find the indices of an element in an int array
struct int_array find_element_in_array (int *x, int n, int element)
{
	int i;
	int count=0;
	int * idx=(int *) malloc(sizeof(int)*n);
	for (i=0;i<n;i++)
	{
		if ( *(x+i)==element )
		{
			*(idx+count)=i;
			count++;
		}
	}
	struct int_array res_array;
	res_array.size=count;
	res_array.pos=idx;
	return res_array;
}

//used for threshold1
double f1(double * x, int * ind_D0, int num_D0, int * ind_D1, int num_D1, double delta, double w)
{
	double res,res1,res2;
	int i;
	res1=res2=0;	
	for (i=0;i<num_D1;i++)
	{
		if ( *(x+ *(ind_D1+i)) > delta )
			res1++;
	}
	for (i=0;i<num_D0;i++)
	{
		if ( *(x+ *(ind_D0+i)) <= delta )
			res2++;
	}
	res=w*res1/num_D1+(1-w)*res2/num_D0;
	return res;
}

//one-dimention funciton
void threshold1(int *D,double *x, int *n, double *w, double *maxtheta, double *xthresholds, int *numxthresholds)
{
	struct int_array array_D0=find_element_in_array(D,*n,0);
	//number of D==0
	int num_D0=array_D0.size;
	//start pointer
	int *ind_D0=array_D0.pos;
	struct int_array array_D1=find_element_in_array(D,*n,1);
	int num_D1=array_D1.size;
	int *ind_D1=array_D1.pos;
	//kk1=(-INF, x)
	double * kk1 = (double *) calloc(*n+1,sizeof(double));
	int i;
	*kk1 = -DBL_MAX;
	for (i=0;i<*n;i++)
	{
		*(kk1+i+1)=*(x+i);
	}
	//sort and find unique elements of kk1
	struct double_array uniq_kk1 =sort_unique_array(kk1, *n+1);
	//the size of the sorted unique array
	int n1=uniq_kk1.size;
	//all the thresholds
	double * xxx = (double *) calloc(n1,sizeof(double));
	for (i=0;i<n1;i++)
	{
		*(xxx+i)= f1(x, ind_D0, num_D0, ind_D1, num_D1, *(uniq_kk1.pos+i), *w);
	}
	//find the max elements,nindex is the number of max
	int nindex=0;
	int * idx=(int *) calloc(n1,sizeof(int));	
	*maxtheta = -DBL_MAX;
	for (i=0;i<n1;i++)
	{
		if (*(xxx+i)>*maxtheta)
		{
			*maxtheta=*(xxx+i);			
			*idx=i;
			nindex=1;
		}else if (*(xxx+i) == *maxtheta)
		{
			*(idx+nindex)=i;
			nindex++;			
		}
	}
	
	for (i=0;i<nindex;i++)
	{
		//printf("%f\n",*(uniq_kk1.pos + *(idx+i)));
		*(xthresholds+i)=*(uniq_kk1.pos + *(idx+i));
	}
	*numxthresholds=nindex;
	
	free(uniq_kk1.pos);
	free(array_D0.pos);
	free(array_D1.pos);
	free(kk1);
	free(xxx);
	free(idx);

}

//based on or rule	
double f2(double * x, double * y, int * ind_D0, int num_D0, int * ind_D1, int num_D1, double delta1,double delta2, double w)
{
	double res,res1,res2;
	int i;
	res1=res2=0;	
	for (i=0;i<num_D1;i++)
	{
		if ( *(x+ *(ind_D1+i)) > delta1 || *(y+ *(ind_D1+i)) > delta2)
			res1++;
	}
	for (i=0;i<num_D0;i++)
	{
		if ( *(x+ *(ind_D0+i)) <= delta1 && *(y+ *(ind_D0+i)) <= delta2)
			res2++;
	}
	res=w*res1/num_D1+(1-w)*res2/num_D0;
	return res;
}

//based on and rule
double f3(double * x, double * y, int * ind_D0, int num_D0, int * ind_D1, int num_D1, double delta1,double delta2, double w)
{
	double res,res1,res2;
	int i;
	res1=res2=0;	
	for (i=0;i<num_D1;i++)
	{
		if ( *(x+ *(ind_D1+i)) > delta1 && *(y+ *(ind_D1+i)) > delta2)
			res1++;
	}
	for (i=0;i<num_D0;i++)
	{
		if ( *(x+ *(ind_D0+i)) <= delta1 || *(y+ *(ind_D0+i)) <= delta2)
			res2++;
	}
	res=w*res1/num_D1+(1-w)*res2/num_D0;
	return res;
}

//2d function,option=1:or,0:and
void threshold2d(int *D,double *x, double *y, int *n, double *w, int *option,double *maxtheta, double *xthresholds, double *ythresholds, int *numthresholds)
{
	struct int_array array_D0=find_element_in_array(D,*n,0);
	int num_D0=array_D0.size;
	int *ind_D0=array_D0.pos;
	struct int_array array_D1=find_element_in_array(D,*n,1);
	int num_D1=array_D1.size;
	int *ind_D1=array_D1.pos;
	double * kk1 = (double *) calloc(*n+1,sizeof(double));
	double * kk2 = (double *) calloc(*n+1,sizeof(double));
	int i,j;
	*kk1 = -DBL_MAX;
	for (i=0;i<*n;i++)
	{
		*(kk1+i+1)=*(x+i);
		//printf("%f\n",*(kk1+i+1));
	}
	//printf("%p\n",(void*)kk1);
	struct double_array uniq_kk1 =sort_unique_array(kk1, *n+1);
	
	//the size of the sorted unique array
	int n1=uniq_kk1.size;
	*kk2 = -DBL_MAX;
	for (i=0;i<*n;i++)
	{
		*(kk2+i+1)=*(y+i);
	}
	struct double_array uniq_kk2 =sort_unique_array(kk2, *n+1);
	int n2=uniq_kk2.size;

	double **kk_expand =(double **) malloc(n1*n2*sizeof(double*));
	if (!kk_expand) printf("%s","mem alloc failure 1 in creating double matrix");
	for (i=0;i<n1*n2;i++) 
	{
		  kk_expand[i]=(double *) malloc(2*sizeof(double));
	}
	
	for (i=0;i<n2;i++)
	{		
		for (j=0;j<n1;j++)
		{
			kk_expand[j+i*(n1)][0]=uniq_kk1.pos[j];
			kk_expand[j+i*(n1)][1]=uniq_kk2.pos[i];
		}
	}
		
	double * xx = (double *) calloc(n1*n2,sizeof(double));
	for (i=0;i<n1*n2;i++)
	{
		if (*option==1)
		{
			*(xx+i)= f2(x, y, ind_D0, num_D0, ind_D1, num_D1, kk_expand[i][0],kk_expand[i][1], *w);
		}else if (*option ==0)
		{
			*(xx+i)= f3(x, y, ind_D0, num_D0, ind_D1, num_D1, kk_expand[i][0],kk_expand[i][1], *w);
		}
	}

	int nindex=0;
	int * idx=(int *) calloc(n1*n2,sizeof(int));	
	*maxtheta = -DBL_MAX;
	for (i=0;i<n1*n2;i++)
	{
		if (*(xx+i)>*maxtheta)
		{
			*maxtheta=*(xx+i);			
			*idx=i;
			nindex=1;
		}else if (*(xx+i) == *maxtheta)
		{
			*(idx+nindex)=i;
			nindex++;			
		}
	}
	
		for (i=0;i<nindex;i++)
	{
		//printf("%f\t%f\n",kk_expand[*(idx+i)][0],kk_expand[*(idx+i)][1]);
		*(xthresholds+i)=kk_expand[*(idx+i)][0];
		*(ythresholds+i)=kk_expand[*(idx+i)][1];
	}
	*numthresholds=nindex;	
	free(array_D0.pos);
	free(array_D1.pos);	
	free(idx);
	free(xx);
	for (i=0;i<n1*n2;i++) free(kk_expand[i]);
	free(kk_expand);
	free(kk1);
	free(kk2);
	free(uniq_kk1.pos);
	free(uniq_kk2.pos);

}
